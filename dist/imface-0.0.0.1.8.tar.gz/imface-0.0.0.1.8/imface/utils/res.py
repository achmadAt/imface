def Response(message: any):
    print(f"<data>{message}</data>")

def Log(message: str):
    print(f"<log>{message}</log>")
